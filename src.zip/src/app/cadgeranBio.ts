export class CadgeranBio {
  cadgeranName!: string;
  cadgeranID!: string;
}